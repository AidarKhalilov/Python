from distutils.core import setup


setup(
    name="Python application",
    version="0.0.1",
    author="Aidar Khalilov",
    author_email="aidarkhalilov4021@gmail.com",
    description="Useless python app",
    include_package_data=True
)
